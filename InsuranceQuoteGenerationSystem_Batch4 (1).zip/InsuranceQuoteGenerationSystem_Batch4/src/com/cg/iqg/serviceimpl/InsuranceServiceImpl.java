package com.cg.iqg.serviceimpl;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;

import com.cg.iqg.dao.InsuranceServiceDao;
import com.cg.iqg.daoimpl.InsuranceServiceDaoImpl;
import com.cg.iqg.model.Accounts;
import com.cg.iqg.model.Policy;
import com.cg.iqg.model.PolicyDetails;
import com.cg.iqg.model.ReportGeneration;
import com.cg.iqg.model.UserRole;
import com.cg.iqg.service.InsuranceService;
import com.cg.iqgexception.IQGException;

public class InsuranceServiceImpl implements InsuranceService {

	InsuranceServiceDao dao = new InsuranceServiceDaoImpl();

	@Override
	public String validUser(UserRole role) throws IQGException {

		return dao.validLogIn(role);
	}

	/*@Override
	public int createAccount(Accounts accounts) throws IQGException {
		// TODO Auto-generated method stub
		//return dao.createAccount(accounts);
	}*/

	@Override
	public boolean validFields(Accounts accounts) throws IQGException {
		List<String> list = new ArrayList<>();
		boolean validFlag = false;
		if(!validName(accounts.getInsuredName()))
		{
			list.add("First letter of name should be capital and maximum limit is 30");
		}
		if(!validStreet(accounts.getInsuredStreet()))
		{
			list.add("First letter of street should be capital!!");
		}
		if(!validCity(accounts.getInsuredCity()))
		{
			list.add("First letter of city should be capital!!");
		}
		if(!validState(accounts.getInsuredState()))
		{
			list.add("First letter of state should be capital!!");
		}
		if(!validZip(accounts.getInsuredZip()))
		{
			list.add("Zip should be a 5 digit number!!!!!!!");
		}
		if(!validBisSeg(accounts.getBusinessSegment()))
		{
			list.add("First letter of Business segment should be capital!!");
		}
		if(!list.isEmpty())
		{
			throw new IQGException(list+ "");
		}
		else
		{
			validFlag = true;
		}
		
		return validFlag;
	}

	public boolean validName(String name) {
		String nameRegEx = "[A-Z]{1}[A-Za-z ]{2,29}";
		return Pattern.matches(nameRegEx, name);
	}

	public boolean validStreet(String street) 
	{
		String streetRegEx = "[A-Z]{1}[A-Za-z]{2,39}";
		return Pattern.matches(streetRegEx, street);
	}

	public boolean validCity(String city) 
	{
		String cityRegEx = "[A-Z]{1}[A-Za-z]{2,14}";
		return Pattern.matches( cityRegEx,city);
	}

	public boolean validState(String  state) {
		String stateRegEx = "[A-Z]{1}[A-Za-z]{2,14}";
		return Pattern.matches(stateRegEx,state);

	}
	public boolean validZip(int zip) {
		String zipRegEx = "[0-9]{5}";
		return Pattern.matches(zipRegEx, Integer.toString(zip));
	}
	public boolean validBisSeg(String bisSeg) {
		String BisSegRegEx = "[A-Z]{1}[A-Za-z]{2,14}";
		return Pattern.matches(BisSegRegEx,bisSeg);
	}

	@Override
	public int createAccount(Accounts accounts) throws IQGException {
		// TODO Auto-generated method stub
		return dao.createAccount(accounts);
	}

	@Override
	public boolean getUserName(String userName) throws IQGException {
		// TODO Auto-generated method stub
		return dao.getUserName(userName);
	}

	@Override
	public boolean checkUserName(String userName) throws IQGException {
		String userNameRegEx="[a-z0-9]{3,20}";
		if(Pattern.matches(userNameRegEx, userName)) {
			return true;
		}else {
			throw new IQGException("username should not contain capital letter and also should contain digits also.");
		}
	}

	@Override
	public boolean checkPassword(String password) throws IQGException {
		String passwordRegEx="[a-zA-Z0-9]{3,12}";
		if(Pattern.matches(passwordRegEx, password)) {
			return true;
		}else {
			throw new IQGException("Password must be alphanumeric and the minimum length should be 3");
		}
	}

	@Override
	public boolean checkUserRole(String userRole) throws IQGException {
		boolean userFlag=false;
		if(userRole.equals("Insured")||userRole.equals("Agent")||userRole.equals("Admin")) {
			userFlag=true;
			return userFlag;
		}else {
			throw new IQGException("User role must be Agent or Insured or Admin");
		}
		
	}

	@Override
	public int addProfile(UserRole role) throws IQGException {
		
		return dao.addProfile(role);
	}

	@Override
	public int createPolicy(int account) throws IQGException {
		// TODO Auto-generated method stub
		//return dao.createPolicy();
		return 0;
	}

	@Override
	public boolean validAccountNumber(int accountNumber) throws IQGException {
		String accountRegEx="[0-9]{7}";
		return Pattern.matches(accountRegEx, Integer.toString(accountNumber));
	}

	@Override
	public boolean existAccount(int accountNumber) throws IQGException {
		// TODO Auto-generated method stub
		return dao.existAccount(accountNumber);
	}

	@Override
	public String getBuisnessSegment(int accountNumber) throws IQGException {
		
		return dao.getBuisnessSegment(accountNumber);
	}

	@Override
	public String getBuisnessSegmentId(String businessSegment) throws IQGException {
		
		return dao.getBuisnessSegmentId(businessSegment);
	}

	@Override
	public List<String> getQuestions(String buisnessSegId) throws IQGException {
		
		return dao.getQuestions(buisnessSegId);
	}

	@Override
	public List<String> getAnswer(String string) throws IQGException {
		// TODO Auto-generated method stub
		return dao.getAnswer(string);
	}

	

	@Override
	public int getWeightage(String string,String option) throws IQGException {
		// TODO Auto-generated method stub
		return dao.getWeightage(string,option);
	}

	@Override
	public int insertPolicy(Policy policy) throws IQGException {
		return dao.insertPolicy(policy);
	}

	@Override
	public String getQuesId(String question) throws IQGException {
		// TODO Auto-generated method stub
		return dao.getQuesId(question);
	}

	@Override
	public List<String> getQuestionId(String buisnessSegId) throws IQGException {
		// TODO Auto-generated method stub
		return dao.getQuestionId(buisnessSegId);
	}

	@Override
	public void insertPolicyDetails(PolicyDetails policyDetails) throws IQGException {
		dao.insertPolicyDetails(policyDetails);
		
	}

	@Override
	public List<Policy> viewPolicyDetails() throws IQGException {
		// TODO Auto-generated method stub
		return dao.viewPolicyDetails();
	}

	@Override
	public List<ReportGeneration> generateReport(int accountNumber1) throws IQGException {
		// TODO Auto-generated method stub
		return dao.generateReport(accountNumber1);
	}

	@Override
	public Policy getPolicy(String userName) throws IQGException {
		// TODO Auto-generated method stub
		return dao.getPolicy(userName);
	}

	

}
